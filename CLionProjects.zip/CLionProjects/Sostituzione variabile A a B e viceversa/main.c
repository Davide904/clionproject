#include <stdio.h>

int main(void) {
    int a = 5; // 5
    int b = 6; // 6
    // PRIMA
    printf("Variabili Prima: A:%d, B:%d\n", a, b);
    // DOPO
    int temp = a; // 5
    a = b; // 6
    b = temp; // 5
    printf("Variabili Dopo: A:%d, B:%d\n", a, b);
    return 0;
}