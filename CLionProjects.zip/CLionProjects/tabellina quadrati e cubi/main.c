#include <stdio.h>
#define MAX 100
#define MIN 0
int main(void) {
    //fai i quadrati e i cubi dei numeri che vanno da 1 a 10
    int i = 0;
    printf ("numero \t quadrato \t cubo \n");
    for (i = MIN; i <= MAX; i++)
    {
    printf("%d \t, %d  \t,  %d \n", i , i * i , i * i * i);
    }

    return 0;
}
