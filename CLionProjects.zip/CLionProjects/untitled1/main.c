#include <stdio.h>
#define NUMERO_MEDIA 5

int main(void) {
    //dichiarazione variabili somma, media e 5 numeri. Poi fanne la somma e la media
    int a = 0, b = 0, c = 0, p = 0, k = 0, somma = 0;
    float media = 0;
    //inserire i numeri
    printf("inserire un numero: \n");
    scanf("%d", &a);
    printf("inserire un numero: \n");
    scanf("%d", &b);
    printf("inserire un numero: \n");
    scanf("%d", &c);
    printf("inserire un numero: \n");
    scanf("%d", &p);
    printf("inserire un numero: \n");
    scanf("%d", &k);

    somma = a + b + c + p + k;
    printf("somma = %d\n", somma);

    media = (float)somma / NUMERO_MEDIA;
    printf("media = %f\n", media);
    return 0;
}
