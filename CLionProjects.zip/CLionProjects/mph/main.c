#include <stdio.h>
#define T_CONV_MPH_TO_KMH 1.61
int main(void) {
    //Scrivere un programma che permetta di gestire la conversione mph -> kmh (miglia orarie in km orari)
    //sapendo che il tasso di conversione mph - kmh è pari a 1.61 (1 mph = 1,61 kmh).
    // Associare tale tasso ad una macro chiamata T_CONV_MPH_TO_KMH.
    // Assegnare alla variabile velocitaMph un valore a piacere e stampare il seguente messaggio in output:
    //Velocità in mph: . mph.
    //Velocità in kmh: . kmh.
    float velocita_mph = 0, velocita_kmh = 0;

    printf("Enter velocita mph: \n", velocita_mph);
    scanf("%f", &velocita_mph);

    velocita_kmh = velocita_mph * T_CONV_MPH_TO_KMH;
    printf("la velocita in kmh: %f \n", velocita_kmh);
    printf("la velocita in mph: %f \n", velocita_mph);


    return 0;
}
