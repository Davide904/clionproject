#include <stdio.h>

int main(void) {
    char c1 = 'a';
    printf("c1: %c \n", c1); //se usi %c ti stampa il carattere.
    char c2 = 'a';
    printf("c2: %d \n", c2); //se usi invece %d ti stampa il valore dell ascii.
    char c3 = 2;
    printf("c3: %d \n", c3); //se usi %d per un numero ti stampa il numero
    char c4 = 2;
    printf("c4: %c \n", c4); //se invece usi %c per un numero ti stampa l ascii
    printf ("%c\n", 5 + 'b' );
    return 0;
}
