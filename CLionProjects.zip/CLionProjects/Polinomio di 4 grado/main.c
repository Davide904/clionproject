#include <stdio.h>
#include <math.h>
//per calcoli matematici
int main(void) {
    //Scrivere un programma che permetta il calcolo del polinomio 5x⁴ - 8x³ + 4x² + 3x – 4.
    //Assegnare alla variabile x un valore a piacere e stampare il risultato a video
    float a = 0, b = 0, c = 0, d = 0, e = 0, x = 0;
    float polinomio = 0;
    printf("inserire un numero: ");
    scanf("%f", &a);
    printf("inserire un numero: ");
    scanf("%f", &b);
    printf("inserire un numero: ");
    scanf("%f", &c);
    printf("inserire un numero: ");
    scanf("%f", &d);
    printf("inserire un numero: ");
    scanf("%f", &e);

    printf("inserisci il valore di x: ");
    scanf("%f", &x);
    //pow per numeri elevati
    polinomio = a * pow (x,4) + b * pow (x, 3) + c *pow ( x, 2) + d* pow (x,1) + e;

    printf("il valore del polinomio e': ");
    printf("%f", polinomio);
    return 0;
}
