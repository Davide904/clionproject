#include <stdio.h>

int main(void)
{
    //Assegnare un valore a entrambi gli interi.
    //Stampare, quindi:
    //La loro somma
    //Il precedente e il successivo di entrambi e la loro media
    int a = 0, b = 0, media = 0, somma = 0;
    int precedente = 0, successivo = 0, precedente2 = 0, successivo2 = 0;//assegnazione variabili
    printf ("\n inserisci il valore di a: ");
    scanf ("%d", &a);
    printf ("\n inserisci il valore di b: ");
    scanf ("%d", &b);
    //visualizziamo i valori
    printf("il valore di a: %d \n", a);
    printf("il valore di b: %d \n", b);
    somma = a + b;
    printf("La somma e' uguale: %d \n", somma);
    media = (somma) / 2;
    printf("La media e' uguale: %d \n", media);
    precedente = a - 1;
    precedente2 = b - 1;
    successivo = a + 1;
    successivo2 = b + 1;
    printf ("\n il valore successivo di a: %d \n", successivo);
    printf ("\n il valore precedente di a: %d \n", precedente);
    printf ("\n il valore successivo di b: %d \n", successivo2);
    printf ("\n il valore precedente di b: %d \n", precedente2);

    return 0;
}
