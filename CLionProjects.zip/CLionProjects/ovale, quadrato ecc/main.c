#include <stdio.h>

int main(void) {
    //crea più figure
    printf("* * * * * * *\n");
    printf("*           * \n");
    printf("*           * \n");
    printf("*           * \n");
    printf("*           * \n");
    printf("* * * * * * *\n");
    //seconda figura
    printf("   * * *\n ");
    printf("*       *\n");
    printf("*         *\n");
    printf("*         *\n");
    printf("*         *\n");
    printf("*         *\n");
    printf(" *       *\n");
    printf("   * * *\n");
}
