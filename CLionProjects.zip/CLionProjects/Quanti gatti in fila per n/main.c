#include <stdio.h>

#define GATTI 12

int main(void)
{
    // Scrivere un programma che, dato un numero complessivo di gatti e il numero di questi per fila,
    // fornisca in output:il numero di file risultanti
    // il numero di gatti rimanenti nel caso in cui l'ultima fila non sia completa
    // L utente definisce il numero dei gatti nelle file, il computer calcola quante file ci sono
    // 12 gatti
    // 3 gatti per fila
    int gattifila = 0;
    printf("inserisci il numero dei gatti per fila: ");
    scanf ("%d", &gattifila);
    gattifila = GATTI / gattifila;
    printf ("%d piselli in fila: ", gattifila);
    return 0;
}
