#include <stdio.h>

    int main(void) {
        //Calcolare la media aritmetica di 3 voti di uno studente e stampare il risultato a schermo.
        //Specifiche: i 3 voti devono essere interi, mentre la media è un numero reale.
        //utilizzare opportunamente il cast esplicito per risolvere eventuali anomalie
        int studente = 0, voto = 0, voto2 = 0, voto3 = 0, somma = 0;
        printf ("\n inserisci il primo voto: ", voto);
        scanf ("%d", &voto);
        printf ("\n inserisci il primo voto: ", voto2);
        scanf ("%d", &voto2);
        printf ("\n inserisci il primo voto: ", voto3);
        scanf ("%d", &voto3);
        somma = voto + voto2 + voto3;
        float media = (float) (somma) / 3;
        //ricordati %f per le variabili float
        printf ("la media dello studente e': %f", media);


        return 0;
    }
