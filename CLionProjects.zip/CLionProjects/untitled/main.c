#include <stdio.h>
//ESERCIZIO 1
int main(void) {
    int a = 5;
    int b = 3;
    int c = 1;

    a - b + c;
    a - b + c * a;
    (a/b) % c;

    printf("la somma n1: %d \n",  a - b + c);
    printf("la somma n2: %d \n",  a - b + c * a);
    printf("la somma n3: %d \n",  (a/b) % c);
    return 0;
}
