#include <stdio.h>
#define NUMERO_CONVERSIONE 32
#define NUMERO_C_F 9/5
#define NUM_F_C 5/9

int main(void) {
    // Scrivere un programma che, ricevuto in input un numero di gradi Celsius
    // traformare f e c.
    // Celsius -> Fahrenheit: F = (N' C * NUMERO_C_F) + 32
    // Fahrenheit -> Celsius: C = (N' F - 32) / x NUM_F_C

    float gradi_c = 0, gradi_f = 0;
    float converti_c_f = 0;    //conversione c in f
    float converti_f_c = 0;   //conversione f in c

    printf("\n Inserisci numero di gradi c: ");
    scanf("%f", &gradi_c);
    converti_c_f = (gradi_c * NUMERO_C_F) + 32;


    printf("\n inserire numero di gradi f: ");
    scanf("%f", &gradi_f);
    converti_f_c = (gradi_f - 32) * NUM_F_C;

    printf("numero di gradi in C: %f \n", converti_c_f);
    printf("numero di gradi in F: %f \n", converti_f_c);


    return 0;
}
